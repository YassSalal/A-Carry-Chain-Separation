# Supplementary Material -- CCSA Wide-Datapath Binary Addition

This package contains all experimental artifacts for the paper
*"A Fixed-Stage Carry-Chain-Separation Architecture for Wide-Datapath
Binary Addition Using Buffered Global Buses."*

| Item | Contents | Paper section |
|---|---|---|
| **Supp. A** | `ccsa_reference.py` -- complete Python reference model (Variant B), exhaustive + random verification | 7.7 |
| **Supp. B** | `ccsa_rtl.v` -- Verilog RTL: combinational (`ccsa_comb`) and 4-cycle sequential (`ccsa_seq`) | 8.4 |
| **Supp. C** | `tb_ccsa.sv` -- self-checking SystemVerilog testbench with 5 SVA checkers | 7.7 |
| **Supp. D** | `synth_one.tcl`, `run_synth_all.tcl` -- Vivado 2023.2 synthesis/PnR scripts | 9.1 |
| **Supp. E** | `electrical_validation_report.md` -- Elmore delay, corners, repeater sensitivity | 1.2, 8.7 |
| **Supp. F** | `raw/` Vivado reports + `parse_reports.py` collator + README | 9.2 |

## Quickstart

```bash
# 1. Algorithm-level verification (Python 3.11, no dependencies)
make verify

# 2. RTL simulation (Icarus Verilog; or xvlog/xelab/xsim, vlog/vsim -- see Supp. C header)
make sim W=32
make sim W=8 EXHAUSTIVE=1        # plus exhaustive: add +EXHAUSTIVE to vvp line

# 3. FPGA synthesis campaign (Vivado 2023.2, Artix-7 xc7a100tcsg324-1)
make synth                       # ~hours; writes Supp_F/raw/

# 4. Collate raw reports to CSV
make collate
```

## Integrity

`SHA256SUMS` lists every file. Verify with `sha256sum -c SHA256SUMS`.

## Scope notes (mirroring the paper)

- The FPGA campaign validates functional correctness, **linear resource
  scaling**, and weak latency **trends**; it does **not** validate the
  absolute width-insensitive delay bound, which is a custom-ASIC model
  prediction (Supp. E) pending layout extraction.
- Baseline adder RTL (Kogge--Stone pipelined/combinational, Brent--Kung)
  resides in the `baselines/` directory of the full repository and is
  synthesized with the identical Supp. D scripts.
